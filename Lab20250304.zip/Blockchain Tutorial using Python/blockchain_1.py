"""
    Name: blockchain_1.py
    Author: 
    Created: 02/10/2024
    Purpose: Demonstrate blockchain in Python
"""

# Start with a basic block
# Define a transaction where Wallet 1 pays 1 bitcoin to Wallet 2
transaction_1 = "Wallet 1 paid 1 bitcoin to Wallet 2"

# Create a genesis block containing the transaction
genesis_block = (transaction_1)

# Print the contents of the genesis block
print(genesis_block)


